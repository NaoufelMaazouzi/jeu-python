Ce jeu est un jeu de plateforme.
Le but est de tuer les ennemis pour accéder à la sortie. Mais attention, une pluie de météorites vous empêchera d'atteindre la fin.

Les commandes sont:
 flèches de droite/gauche pour se décplacer
 espace pour sauter
 f pour lancer des boules de feu

Pour lancer le jeu il faut se placer dans le dossier et lancer la commander py startGame.py